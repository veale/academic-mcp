"""Academic Research MCP Server."""
